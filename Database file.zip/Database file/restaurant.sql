-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 12, 2018 at 07:53 AM
-- Server version: 10.1.28-MariaDB
-- PHP Version: 5.6.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `restaurant`
--

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES
(2, 'shuvo', '', '2018-08-02 03:53:08', '2018-08-02 03:53:08'),
(3, 'shuvo sarker', 'shuvo-sarker', '2018-08-02 03:54:18', '2018-08-02 03:54:18'),
(4, 'shuvos', 'shuvos', '2018-08-02 03:54:31', '2018-08-02 03:54:31'),
(5, 'dddddddddddddd', 'dddddddddddddd', '2018-08-02 03:56:08', '2018-08-02 03:56:08');

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE `contacts` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contacts`
--

INSERT INTO `contacts` (`id`, `name`, `email`, `subject`, `message`, `created_at`, `updated_at`) VALUES
(2, 'shuvo sarker shuvo', 'softwareshuvosarker@gmail.com', 'c language', 'ddddddddddddddddddddddddddddd ffffffffffffffffffffffffffffff ggggggggggggggggggggggggggg bbbbbbbbbbbbbbbbbb', '2018-08-04 22:26:58', '2018-08-04 22:26:58'),
(3, 'shuvo sarker shuvo', 'softwareshuvosarker@gmail.com', 'c language', 'uuuuuuuuuuuuuuu', '2018-08-05 10:57:29', '2018-08-05 10:57:29');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` int(10) UNSIGNED NOT NULL,
  `category_id` int(10) UNSIGNED NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `price` int(11) NOT NULL,
  `image` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `items`
--

INSERT INTO `items` (`id`, `category_id`, `name`, `description`, `price`, `image`, `created_at`, `updated_at`) VALUES
(3, 5, 'shuvo sarker shuvo', 'ffffffffffffffffffffffff', 10000, 'shuvo-sarker-shuvo-2018-08-02-5b63594e2d9c9.jpg', '2018-08-02 12:07:45', '2018-08-02 13:19:42'),
(4, 2, 'shuvo sarker shuvo', 'eeeeeeeeeeeeeeeeee', 333, 'shuvo-sarker-shuvo-2018-08-02-5b636140f09db.png', '2018-08-02 13:53:36', '2018-08-02 13:53:36'),
(5, 2, 'dddddddddddddd', 'qqqqqqqqqqqqqqq', 444, 'dddddddddddddd-2018-08-02-5b636165deb14.png', '2018-08-02 13:54:13', '2018-08-02 13:54:13'),
(6, 3, 'shuvo sarker shuvo', 'dddddddddddddd', 55, 'shuvo-sarker-shuvo-2018-08-02-5b6362047e89d.jpg', '2018-08-02 13:56:52', '2018-08-02 13:56:52'),
(7, 3, 'dddddddddddddd', 'fffffffffffffff', 66, 'dddddddddddddd-2018-08-02-5b63622da1175.jpg', '2018-08-02 13:57:33', '2018-08-02 13:57:33'),
(8, 4, 'shuvos', 'gggggggggggggggg', 88, 'shuvos-2018-08-02-5b6362841453f.jpg', '2018-08-02 13:59:00', '2018-08-02 13:59:00');

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2018_08_01_110802_create_slidertudents_table', 2),
(4, '2018_08_02_062956_create_categories_table', 3),
(5, '2018_08_02_142342_create_items_table', 4),
(6, '2018_08_03_051156_create_reservations_table', 5),
(7, '2018_08_05_031514_create_contacts_table', 6);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reservations`
--

CREATE TABLE `reservations` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_and_time` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `message` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(1) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `reservations`
--

INSERT INTO `reservations` (`id`, `name`, `phone`, `email`, `date_and_time`, `message`, `status`, `created_at`, `updated_at`) VALUES
(2, 'shuvo sarker shuvo', '1765735662', 'softwareshuvosarker@gmail.com', '19 December 1899 - 09:11 PM', 'dddddddddddddgggggggggggg', 1, '2018-08-03 13:05:07', '2018-08-03 13:05:21'),
(3, 'shuvos', '1765735662', 'ifranul33-384@diu.edu.bd', '06 December 1899 - 09:11 AM', 'fffffffff', 1, '2018-08-05 10:56:01', '2018-08-05 23:54:56'),
(4, 'shuvos', '1765735662', 'shubha629@diu.edu.bd', '19 December 1899 - 03:11 PM', 'rhjkvm, .?', 1, '2018-08-06 00:04:05', '2018-08-06 00:19:10'),
(5, 'dddddddddddddd', '1765735662', 'softwareshuvosarker@gmail.com', '04 December 1899 - 07:11 AM', 'eeeeeeeeeeeeeeeeeee', 1, '2018-08-06 00:04:56', '2018-08-06 00:14:52'),
(6, 'shuvo sarker shuvo', '1765735662', 'ifranul33-384@diu.edu.bd', '04 December 1899 - 09:11 AM', 'bbbbbbbbbbbb', 1, '2018-08-06 01:32:21', '2018-08-06 01:32:34');

-- --------------------------------------------------------

--
-- Table structure for table `slidertudents`
--

CREATE TABLE `slidertudents` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sub_title` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default.png',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `slidertudents`
--

INSERT INTO `slidertudents` (`id`, `title`, `sub_title`, `image`, `created_at`, `updated_at`) VALUES
(2, 'ffffffffaaaaaaaaaaaaaacccccccccccc', 'bbbbbbbbb', 'ffffffff-2018-08-01-5b61ae5880056.jpg', '2018-08-01 06:58:00', '2018-08-01 22:36:55'),
(3, 'ccccccccccc', 'ffffffffffffffffffffff', 'ccccccccccc-2018-08-01-5b61b064e1134.jpg', '2018-08-01 07:06:44', '2018-08-01 07:06:44'),
(4, 'ccccccccccchhhhhhhhhhhhh', 'bbbbbbbbbaaaaaaaaaaaaa', 'ccccccccccchhhhhhhhhhhhh-2018-08-02-5b627956620e4.jpg', '2018-08-01 21:24:06', '2018-08-01 21:24:06'),
(5, 'shuvo', 'jjjjjjj', 'shuvo-2018-08-02-5b627cdf1e44b.jpg', '2018-08-01 21:39:11', '2018-08-01 21:39:11');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `name` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'shuvo', 'shuvosarker19@gmail.com', '$2y$10$U/IUeSKd1qSi8vhL93eZWOjtZ2mXz/LiKfiuKnOtpjgWs3fb9AOZy', '2WfxfcYR1p0PCCXxiJxMVUd2LbZtnsdiERzdeH0zyuQ3kRaIpYwEKclYMBur', '2018-08-01 01:59:23', '2018-08-01 01:59:23');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contacts`
--
ALTER TABLE `contacts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `items_category_id_foreign` (`category_id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `reservations`
--
ALTER TABLE `reservations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slidertudents`
--
ALTER TABLE `slidertudents`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `contacts`
--
ALTER TABLE `contacts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `reservations`
--
ALTER TABLE `reservations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `slidertudents`
--
ALTER TABLE `slidertudents`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `items`
--
ALTER TABLE `items`
  ADD CONSTRAINT `items_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
