

    <footer class="footer">
        <div class="container-fluid">

            <p class="copyright pull-right">
                &copy;
                <script>
                    document.write(new Date().getFullYear())
                </script>
                <a href="#">tustedIt Tim</a>, made with love for a better web
            </p>
        </div>
    </footer>

